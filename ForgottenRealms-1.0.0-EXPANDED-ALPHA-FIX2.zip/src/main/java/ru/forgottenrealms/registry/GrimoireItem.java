package ru.forgottenrealms.registry;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class GrimoireItem extends Item {
    public enum School { EMBER, TIDE, GALE, ROOT, VOID }
    private final School school;

    public GrimoireItem(Properties properties, School school) {
        super(properties.stacksTo(1).durability(160));
        this.school = school;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(player instanceof ServerPlayer caster) || level.isClientSide) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }
        if (caster.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.fail(stack);

        switch (school) {
            case EMBER -> {
                List<Entity> targets = level.getEntities(caster, caster.getBoundingBox().inflate(7),
                        e -> e instanceof net.minecraft.world.entity.LivingEntity && e.isAlive());
                for (Entity target : targets) {
                    if (target instanceof net.minecraft.world.entity.LivingEntity living) {
                        living.setRemainingFireTicks(100);
                        living.hurt(caster.damageSources().indirectMagic(caster, caster), 5.0F);
                    }
                }
                caster.sendSystemMessage(Component.literal("§6Пламя вспыхивает вокруг вас."));
            }
            case TIDE -> {
                caster.heal(8.0F);
                caster.removeEffect(MobEffects.POISON);
                caster.removeEffect(MobEffects.WITHER);
                caster.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 160, 0));
                caster.sendSystemMessage(Component.literal("§bВолна исцеления окутывает вас."));
            }
            case GALE -> {
                Vec3 look = caster.getLookAngle();
                caster.push(look.x * 1.8, 0.75 + Math.max(0, look.y), look.z * 1.8);
                caster.hurtMarked = true;
                caster.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 120, 0));
                caster.sendSystemMessage(Component.literal("§fВетер подхватывает вас."));
            }
            case ROOT -> {
                caster.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
                caster.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 0));
                caster.sendSystemMessage(Component.literal("§aКорни природы восстанавливают силы."));
            }
            case VOID -> {
                Vec3 look = caster.getLookAngle();
                Vec3 destination = caster.position().add(look.scale(8));
                caster.teleportTo(destination.x, destination.y, destination.z);
                caster.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 100, 0));
                caster.sendSystemMessage(Component.literal("§5Пустота искажает пространство."));
            }
        }
        caster.getCooldowns().addCooldown(this, 100);
        stack.hurtAndBreak(1, caster, Player.getSlotForHand(hand));
        return InteractionResultHolder.sidedSuccess(stack, false);
    }
}

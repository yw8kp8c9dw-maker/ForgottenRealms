package ru.forgottenrealms.registry;

import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import ru.forgottenrealms.ForgottenRealms;

public final class FRItems {
    public static final DeferredRegister.Items ITEMS =
            DeferredRegister.createItems(ForgottenRealms.MOD_ID);

    public static final DeferredItem<Item> MOONLEAF =
            ITEMS.registerSimpleItem("moonleaf", new Item.Properties());

    public static final DeferredItem<Item> FEVER_TONIC =
            ITEMS.register("fever_tonic", () -> new MedicineItem(new Item.Properties(), MedicineItem.Kind.FEVER));

    public static final DeferredItem<Item> ANTIDOTE =
            ITEMS.register("antidote", () -> new MedicineItem(new Item.Properties(), MedicineItem.Kind.ANTIDOTE));

    public static final DeferredItem<Item> RESTORATIVE_ELIXIR =
            ITEMS.register("restorative_elixir", () -> new MedicineItem(new Item.Properties(), MedicineItem.Kind.RESTORATIVE));

    public static final DeferredItem<Item> ARCANE_DUST =
            ITEMS.registerSimpleItem("arcane_dust", new Item.Properties());

    public static final DeferredItem<Item> GRIMOIRE_EMBER =
            ITEMS.register("grimoire_ember", () -> new GrimoireItem(new Item.Properties(), GrimoireItem.School.EMBER));

    public static final DeferredItem<Item> GRIMOIRE_TIDE =
            ITEMS.register("grimoire_tide", () -> new GrimoireItem(new Item.Properties(), GrimoireItem.School.TIDE));

    public static final DeferredItem<Item> GRIMOIRE_GALE =
            ITEMS.register("grimoire_gale", () -> new GrimoireItem(new Item.Properties(), GrimoireItem.School.GALE));

    public static final DeferredItem<Item> GRIMOIRE_ROOT =
            ITEMS.register("grimoire_root", () -> new GrimoireItem(new Item.Properties(), GrimoireItem.School.ROOT));

    public static final DeferredItem<Item> GRIMOIRE_VOID =
            ITEMS.register("grimoire_void", () -> new GrimoireItem(new Item.Properties(), GrimoireItem.School.VOID));

    private FRItems() {}
}

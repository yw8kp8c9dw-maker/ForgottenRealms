package ru.forgottenrealms.registry;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import ru.forgottenrealms.system.DiseaseSystem;

public class MedicineItem extends Item {
    public enum Kind { FEVER, ANTIDOTE, RESTORATIVE }
    private final Kind kind;

    public MedicineItem(Properties properties, Kind kind) {
        super(properties.stacksTo(16));
        this.kind = kind;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            switch (kind) {
                case FEVER -> {
                    DiseaseSystem.cure(player, "fever");
                    player.sendSystemMessage(Component.translatable("message.forgotten_realms.fever_cured"));
                }
                case ANTIDOTE -> {
                    DiseaseSystem.cure(player, "plague");
                    DiseaseSystem.cure(player, "poisoning");
                    DiseaseSystem.cure(player, "blight");
                    player.sendSystemMessage(Component.translatable("message.forgotten_realms.antidote_used"));
                }
                case RESTORATIVE -> {
                    DiseaseSystem.cure(player, "fever");
                    DiseaseSystem.cure(player, "plague");
                    DiseaseSystem.cure(player, "poisoning");
                    DiseaseSystem.cure(player, "frostbite");
                    DiseaseSystem.cure(player, "blight");
                    DiseaseSystem.cure(player, "curse");
                    player.heal(6.0F);
                    player.getFoodData().eat(6, 0.6F);
                    player.sendSystemMessage(Component.translatable("message.forgotten_realms.restored"));
                }
            }
            if (!player.getAbilities().instabuild) stack.shrink(1);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}

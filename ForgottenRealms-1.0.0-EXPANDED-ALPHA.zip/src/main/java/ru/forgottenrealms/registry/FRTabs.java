package ru.forgottenrealms.registry;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import ru.forgottenrealms.ForgottenRealms;

public final class FRTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ForgottenRealms.MOD_ID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN =
            TABS.register("main", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.forgotten_realms"))
                    .icon(() -> new ItemStack(FRItems.GRIMOIRE_EMBER.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(FRItems.MOONLEAF.get());
                        output.accept(FRItems.FEVER_TONIC.get());
                        output.accept(FRItems.ANTIDOTE.get());
                        output.accept(FRItems.RESTORATIVE_ELIXIR.get());
                        output.accept(FRItems.ARCANE_DUST.get());
                        output.accept(FRItems.GRIMOIRE_EMBER.get());
                        output.accept(FRItems.GRIMOIRE_TIDE.get());
                        output.accept(FRItems.GRIMOIRE_GALE.get());
                        output.accept(FRItems.GRIMOIRE_ROOT.get());
                        output.accept(FRItems.GRIMOIRE_VOID.get());
                    }).build());

    private FRTabs() {}
}

package ru.forgottenrealms;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import ru.forgottenrealms.registry.FRItems;
import ru.forgottenrealms.registry.FRTabs;
import ru.forgottenrealms.system.DiseaseSystem;
import ru.forgottenrealms.system.WorldEventSystem;

@Mod(ForgottenRealms.MOD_ID)
public final class ForgottenRealms {
    public static final String MOD_ID = "forgotten_realms";

    public ForgottenRealms(IEventBus modBus) {
        FRItems.ITEMS.register(modBus);
        FRTabs.TABS.register(modBus);
        NeoForge.EVENT_BUS.register(new DiseaseSystem());
        NeoForge.EVENT_BUS.register(new WorldEventSystem());
    }
}

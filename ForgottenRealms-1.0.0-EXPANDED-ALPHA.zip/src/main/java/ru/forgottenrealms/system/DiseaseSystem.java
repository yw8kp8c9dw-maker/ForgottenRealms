package ru.forgottenrealms.system;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

import java.util.Random;

public final class DiseaseSystem {
    private static final String DATA_KEY = "ForgottenRealmsDisease";
    private static final Random RANDOM = new Random();

    @SubscribeEvent
    public void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (player.tickCount % 20 != 0) return;

        CompoundTag root = player.getPersistentData();
        CompoundTag data = root.getCompound(DATA_KEY);

        // A daily exposure roll: chance is intentionally low and configurable.
        if (player.tickCount % 24000 == 0 && data.getString("active").isEmpty()) {
            if (RANDOM.nextDouble() < 0.035D) {
                String[] diseases = {"fever", "plague", "poisoning", "frostbite", "blight", "curse"};
                String disease = diseases[RANDOM.nextInt(diseases.length)];
                data.putString("active", disease);
                data.putInt("stage", 1);
                data.putLong("started", player.level().getGameTime());
                player.displayClientMessage(
                        net.minecraft.network.chat.Component.translatable("message.forgotten_realms.symptoms_begin"), true);
            }
        }

        String disease = data.getString("active");
        if (!disease.isEmpty()) {
            long elapsed = player.level().getGameTime() - data.getLong("started");
            int stage = elapsed > 72000 ? 3 : elapsed > 36000 ? 2 : 1;
            data.putInt("stage", stage);

            if ("fever".equals(disease)) {
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 50, stage - 1, false, false));
                if (stage >= 2) player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 50, 0, false, false));
                if (stage >= 3 && player.tickCount % 200 == 0) player.hurt(player.damageSources().magic(), 1.0F);
            } else if ("plague".equals(disease)) {
                player.addEffect(new MobEffectInstance(MobEffects.HUNGER, 50, stage - 1, false, false));
                if (stage >= 2) player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 50, 0, false, false));
                if (stage >= 3 && player.tickCount % 300 == 0) player.hurt(player.damageSources().magic(), 1.0F);
            } else if ("poisoning".equals(disease)) {
                player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 50, 0, false, false));
                if (stage >= 2) player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 50, 0, false, false));
            } else if ("frostbite".equals(disease)) {
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 50, stage >= 2 ? 1 : 0, false, false));
                if (stage >= 2) player.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 50, 0, false, false));
                if (stage >= 3 && player.tickCount % 240 == 0) player.hurt(player.damageSources().freeze(), 1.0F);
            } else if ("blight".equals(disease)) {
                player.addEffect(new MobEffectInstance(MobEffects.POISON, 50, stage >= 2 ? 1 : 0, false, false));
                player.addEffect(new MobEffectInstance(MobEffects.HUNGER, 50, stage - 1, false, false));
            } else if ("curse".equals(disease)) {
                player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 50, stage - 1, false, false));
                if (stage >= 2) player.addEffect(new MobEffectInstance(MobEffects.WITHER, 50, 0, false, false));
                if (stage >= 3 && player.tickCount % 300 == 0) player.hurt(player.damageSources().wither(), 1.0F);
            }
        }
        root.put(DATA_KEY, data);
    }

    public static void cure(ServerPlayer player, String disease) {
        CompoundTag root = player.getPersistentData();
        CompoundTag data = root.getCompound(DATA_KEY);
        if (disease.equals(data.getString("active")) || "all".equals(disease)) {
            data.remove("active");
            data.remove("stage");
            data.remove("started");
            root.put(DATA_KEY, data);
        }
    }
}

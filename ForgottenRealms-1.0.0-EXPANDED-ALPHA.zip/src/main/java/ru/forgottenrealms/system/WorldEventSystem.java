package ru.forgottenrealms.system;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Skeleton;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.monster.Spider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.Random;

public final class WorldEventSystem {
    private static final Random RANDOM = new Random();
    private static long lastWorldEvent = 0;
    private static long lastStructure = 0;

    @SubscribeEvent
    public void onServerTick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        ServerLevel level = server.getLevel(Level.OVERWORLD);
        if (level == null) return;
        long time = level.getGameTime();

        // Ambient world event every 18-30 in-game days.
        if (time - lastWorldEvent > 24000L * (18 + RANDOM.nextInt(13))) {
            lastWorldEvent = time;
            triggerWorldEvent(server, level);
        }

        // A medium-frequency ruin/castle encounter, built near an online player.
        if (time - lastStructure > 24000L * 5) {
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                if (player.level() == level && RANDOM.nextFloat() < 0.30F) {
                    if (buildEncounterStructure(level, player.blockPosition())) {
                        lastStructure = time;
                        player.sendSystemMessage(Component.literal("§6Вдалеке обнаружено древнее укрепление."));
                        break;
                    }
                }
            }
        }
    }

    private static void triggerWorldEvent(MinecraftServer server, ServerLevel level) {
        int kind = RANDOM.nextInt(6);
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (player.level() != level) continue;
            switch (kind) {
                case 0 -> {
                    player.sendSystemMessage(Component.literal("§5Над миром сгущается проклятое затмение..."));
                    for (int i = 0; i < 4; i++) spawnHostile(level, player.blockPosition(), i);
                }
                case 1 -> {
                    player.sendSystemMessage(Component.literal("§cВ окрестностях замечена стая нежити!"));
                    for (int i = 0; i < 5; i++) spawnHostile(level, player.blockPosition(), i);
                }
                case 2 -> {
                    player.sendSystemMessage(Component.literal("§aПутешественники оставили припасы неподалёку."));
                    BlockPos chestPos = player.blockPosition().offset(3, 0, 3);
                    chestPos = level.getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, chestPos);
                    if (level.isEmptyBlock(chestPos)) {
                        level.setBlock(chestPos, Blocks.CHEST.defaultBlockState(), 3);
                        if (level.getBlockEntity(chestPos) instanceof ChestBlockEntity chest) {
                            chest.setItem(0, new ItemStack(Items.BREAD, 4 + RANDOM.nextInt(5)));
                            chest.setItem(1, new ItemStack(Items.IRON_INGOT, 1 + RANDOM.nextInt(4)));
                            chest.setItem(2, new ItemStack(Items.GOLD_INGOT, 1 + RANDOM.nextInt(3)));
                        }
                    }
                }
                case 3 -> {
                    player.sendSystemMessage(Component.literal("§dМагические потоки усилились. Вы ощущаете прилив сил."));
                    player.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.LUCK, 12000, 0));
                    player.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.REGENERATION, 600, 0));
                }
                case 4 -> {
                    player.sendSystemMessage(Component.literal("§eСтранствующий торговец появился неподалёку."));
                    spawnAt(level, EntityType.WANDERING_TRADER, player.blockPosition().offset(3, 0, 3));
                    spawnAt(level, EntityType.LLAMA, player.blockPosition().offset(4, 0, 3));
                }
                default -> {
                    player.sendSystemMessage(Component.literal("§4Из разлома выходит древний страж!"));
                    EntityType<? extends Mob> bossType = switch (RANDOM.nextInt(3)) {
                        case 0 -> EntityType.RAVAGER;
                        case 1 -> EntityType.EVOKER;
                        default -> EntityType.WARDEN;
                    };
                    Mob boss = bossType.create(level);
                    if (boss != null) {
                        BlockPos spawn = level.getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                                player.blockPosition().offset(5, 0, 5));
                        boss.moveTo(spawn.getX() + .5, spawn.getY(), spawn.getZ() + .5, 0, 0);
                        boss.setCustomName(Component.literal("§5Страж Разлома"));
                        boss.setCustomNameVisible(true);
                        level.addFreshEntity(boss);
                    }
                }
            }
        }
    }


    /** Picks one of several handcrafted encounter sites. Ownership is rolled independently. */
    private static boolean buildEncounterStructure(ServerLevel level, BlockPos near) {
        int kind = RANDOM.nextInt(5);
        int dx = RANDOM.nextInt(81) - 40;
        int dz = RANDOM.nextInt(81) - 40;
        BlockPos base = level.getHeightmapPos(
                net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                near.offset(dx, 0, dz));
        if (!level.hasChunkAt(base) || base.getY() < level.getMinBuildHeight() + 8
                || base.getY() > level.getMaxBuildHeight() - 24 || level.getBlockState(base.below()).isAir()) return false;
        switch (kind) {
            case 0 -> buildSmallKeep(level, base);
            case 1 -> buildWizardTower(level, base);
            case 2 -> buildCrypt(level, base);
            case 3 -> buildBanditCamp(level, base);
            default -> buildRuinedVillage(level, base);
        }
        assignOwner(level, base, kind);
        return true;
    }

    private static void buildWizardTower(ServerLevel level, BlockPos base) {
        for (int y=0; y<15; y++) for (int x=-3; x<=3; x++) for (int z=-3; z<=3; z++) {
            double d = x*x + z*z;
            if (d <= 12 && (d >= 7 || y == 0 || y == 14))
                level.setBlock(base.offset(x,y,z), y==14 ? Blocks.POLISHED_DEEPSLATE.defaultBlockState() : Blocks.DEEPSLATE_BRICKS.defaultBlockState(), 3);
            else if (d < 7 && y>0 && y<14) level.setBlock(base.offset(x,y,z), Blocks.AIR.defaultBlockState(), 3);
        }
        for (int y=1; y<4; y++) level.setBlock(base.offset(0,y,-3), Blocks.AIR.defaultBlockState(), 3);
        level.setBlock(base.offset(0,1,0), Blocks.ENCHANTING_TABLE.defaultBlockState(), 3);
        level.setBlock(base.offset(2,1,0), Blocks.CHEST.defaultBlockState(), 3);
        fillChest(level, base.offset(2,1,0), true);
        for (int x=-2;x<=2;x+=4) for (int z=-2;z<=2;z+=4)
            level.setBlock(base.offset(x,15,z), Blocks.SOUL_LANTERN.defaultBlockState(), 3);
    }

    private static void buildCrypt(ServerLevel level, BlockPos base) {
        for (int x=-5;x<=5;x++) for (int z=-5;z<=5;z++) {
            level.setBlock(base.offset(x,-1,z), Blocks.DEEPSLATE_BRICKS.defaultBlockState(), 3);
            if (Math.abs(x)==5 || Math.abs(z)==5) for (int y=0;y<=3;y++)
                level.setBlock(base.offset(x,y,z), Blocks.CRACKED_DEEPSLATE_BRICKS.defaultBlockState(), 3);
        }
        for (int x=-4;x<=4;x++) for (int z=-4;z<=4;z++)
            if (Math.abs(x)<5 && Math.abs(z)<5) level.setBlock(base.offset(x,0,z), Blocks.AIR.defaultBlockState(), 3);
        level.setBlock(base.offset(0,0,0), Blocks.CHEST.defaultBlockState(), 3);
        fillChest(level, base, true);
        level.setBlock(base.offset(0,1,0), Blocks.SKELETON_SKULL.defaultBlockState(), 3);
    }

    private static void buildBanditCamp(ServerLevel level, BlockPos base) {
        for (int i=0;i<3;i++) {
            int x=(i-1)*4;
            for (int y=0;y<3;y++) for (int z=-2;z<=2;z++) {
                level.setBlock(base.offset(x-2+y,y,z), Blocks.RED_WOOL.defaultBlockState(), 3);
                level.setBlock(base.offset(x+2-y,y,z), Blocks.RED_WOOL.defaultBlockState(), 3);
            }
            for (int z=-2;z<=2;z++) level.setBlock(base.offset(x,3,z), Blocks.WHITE_WOOL.defaultBlockState(), 3);
        }
        level.setBlock(base.offset(0,0,4), Blocks.CAMPFIRE.defaultBlockState(), 3);
        level.setBlock(base.offset(3,0,4), Blocks.CHEST.defaultBlockState(), 3);
        fillChest(level, base.offset(3,0,4), false);
    }

    private static void buildRuinedVillage(ServerLevel level, BlockPos base) {
        for (int h=0;h<2;h++) {
            int ox=h==0?-4:4;
            for (int x=-2;x<=2;x++) for (int z=-2;z<=2;z++) {
                boolean wall=Math.abs(x)==2 || Math.abs(z)==2;
                if (wall) {
                    for (int y=0;y<3;y++) if (!(z==-2 && x==0 && y<2))
                        level.setBlock(base.offset(ox+x,y,z), (RANDOM.nextBoolean()?Blocks.COBBLESTONE:Blocks.MOSSY_COBBLESTONE).defaultBlockState(), 3);
                } else if (x==0 && z==0) {
                    level.setBlock(base.offset(ox+x,0,z), Blocks.CHEST.defaultBlockState(), 3);
                }
            }
            BlockPos chest=base.offset(ox,0,0);
            if (level.getBlockState(chest).is(Blocks.CHEST)) fillChest(level,chest,false);
        }
        level.setBlock(base.offset(0,0,0), Blocks.MOSSY_COBBLESTONE.defaultBlockState(), 3);
        level.setBlock(base.offset(0,1,0), Blocks.WATER.defaultBlockState(), 3);
    }

    private static void assignOwner(ServerLevel level, BlockPos base, int structure) {
        int owner=RANDOM.nextInt(4); // mixed: living faction, raiders, monsters, abandoned
        if (owner==0) {
            spawnAt(level, EntityType.VILLAGER, base.offset(1,1,1));
            spawnAt(level, EntityType.IRON_GOLEM, base.offset(-2,1,0));
        } else if (owner==1) {
            spawnAt(level, EntityType.PILLAGER, base.offset(2,1,2));
            spawnAt(level, EntityType.VINDICATOR, base.offset(-2,1,-2));
            if (structure==1) spawnAt(level, EntityType.EVOKER, base.offset(0,1,2));
        } else if (owner==2) {
            spawnAt(level, EntityType.ZOMBIE, base.offset(1,1,1));
            spawnAt(level, EntityType.SKELETON, base.offset(-1,1,-1));
            spawnAt(level, EntityType.SPIDER, base.offset(2,1,-2));
        }
    }

    private static void spawnAt(ServerLevel level, EntityType<? extends Mob> type, BlockPos pos) {
        Mob mob=type.create(level);
        if (mob!=null) {
            BlockPos safe=level.getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,pos);
            mob.moveTo(safe.getX()+.5,safe.getY(),safe.getZ()+.5,RANDOM.nextFloat()*360F,0);
            level.addFreshEntity(mob);
        }
    }

    private static void fillChest(ServerLevel level, BlockPos pos, boolean rare) {
        if (level.getBlockEntity(pos) instanceof ChestBlockEntity chest) {
            chest.setItem(0,new ItemStack(rare?Items.ENCHANTED_BOOK:Items.BREAD,1+RANDOM.nextInt(3)));
            chest.setItem(1,new ItemStack(Items.IRON_INGOT,2+RANDOM.nextInt(5)));
            chest.setItem(2,new ItemStack(rare?Items.DIAMOND:Items.GOLD_INGOT,1+RANDOM.nextInt(3)));
            chest.setItem(3,new ItemStack(Items.EXPERIENCE_BOTTLE,2+RANDOM.nextInt(5)));
        }
    }

    private static void spawnHostile(ServerLevel level, BlockPos center, int index) {
        int dx = RANDOM.nextInt(13) - 6;
        int dz = RANDOM.nextInt(13) - 6;
        BlockPos spawn = level.getHeightmapPos(
                net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                center.offset(dx, 0, dz));
        Mob mob;
        int type = RANDOM.nextInt(3);
        if (type == 0) mob = EntityType.ZOMBIE.create(level);
        else if (type == 1) mob = EntityType.SKELETON.create(level);
        else mob = EntityType.SPIDER.create(level);
        if (mob != null) {
            mob.moveTo(spawn.getX() + 0.5, spawn.getY(), spawn.getZ() + 0.5,
                    RANDOM.nextFloat() * 360F, 0);
            level.addFreshEntity(mob);
        }
    }

    private static boolean buildSmallKeep(ServerLevel level, BlockPos near) {
        int dx = RANDOM.nextInt(65) - 32;
        int dz = RANDOM.nextInt(65) - 32;
        BlockPos base = level.getHeightmapPos(
                net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                near.offset(dx, 0, dz));
        if (base.getY() < level.getMinBuildHeight() + 5 || base.getY() > level.getMaxBuildHeight() - 18) return false;
        if (!level.hasChunkAt(base)) return false;
        if (level.getBlockState(base.below()).isAir()) return false;

        // Compact 9x9 ruined keep: stone shell, battlements, entrance and treasure chest.
        for (int x = -4; x <= 4; x++) for (int z = -4; z <= 4; z++) {
            for (int y = 0; y <= 7; y++) {
                BlockPos p = base.offset(x, y, z);
                boolean wall = Math.abs(x) == 4 || Math.abs(z) == 4;
                if (wall) level.setBlock(p, (y >= 6 && RANDOM.nextFloat() < 0.18F
                        ? Blocks.AIR.defaultBlockState()
                        : Blocks.COBBLESTONE.defaultBlockState()), 3);
                else if (y == 0) level.setBlock(p, Blocks.STONE_BRICKS.defaultBlockState(), 3);
                else if (y == 7 && (Math.abs(x) == 3 || Math.abs(z) == 3))
                    level.setBlock(p, Blocks.STONE_BRICK_WALL.defaultBlockState(), 3);
                else if (y > 0 && y < 7) level.setBlock(p, Blocks.AIR.defaultBlockState(), 3);
            }
        }
        // Doorway
        level.setBlock(base.offset(0, 1, -4), Blocks.AIR.defaultBlockState(), 3);
        level.setBlock(base.offset(0, 2, -4), Blocks.AIR.defaultBlockState(), 3);
        level.setBlock(base.offset(0, 3, -4), Blocks.AIR.defaultBlockState(), 3);
        // Corner towers
        for (int x : new int[]{-4,4}) for (int z : new int[]{-4,4}) {
            for (int y=1; y<=10; y++) level.setBlock(base.offset(x,y,z), Blocks.STONE_BRICKS.defaultBlockState(), 3);
            for (int xx=-1;xx<=1;xx++) for (int zz=-1;zz<=1;zz++)
                if (Math.abs(xx)==1 || Math.abs(zz)==1)
                    level.setBlock(base.offset(x+xx,11,z+zz), Blocks.STONE_BRICK_WALL.defaultBlockState(), 3);
        }
        BlockPos chestPos = base.offset(2,1,2);
        level.setBlock(chestPos, Blocks.CHEST.defaultBlockState(), 3);
        if (level.getBlockEntity(chestPos) instanceof ChestBlockEntity chest) {
            chest.setItem(0, new ItemStack(Items.GOLD_INGOT, 3 + RANDOM.nextInt(6)));
            chest.setItem(1, new ItemStack(Items.IRON_INGOT, 4 + RANDOM.nextInt(8)));
            chest.setItem(2, new ItemStack(Items.DIAMOND, RANDOM.nextInt(3)));
            chest.setItem(3, new ItemStack(Items.EXPERIENCE_BOTTLE, 2 + RANDOM.nextInt(5)));
        }
        for (int i=0;i<3;i++) spawnHostile(level, base.offset(0,0,0), i);
        return true;
    }
}
